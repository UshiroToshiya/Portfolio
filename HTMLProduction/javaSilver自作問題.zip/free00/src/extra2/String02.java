package extra2;

public class String02 {

	public static void main(String[] args) {
		String s = new String("A");
		String f = new String("A");
		
		System.out.println(s == f);
		System.out.println(s.equals(f));

	}

}
