package extra2;

public class For02 {

	public static void main(String[] args) {

		int[] a ={1, 2, 3};
		for(int i = 0; i < a.length; i++,A(10)){
			System.out.println(a[i]);
		}

	}
	public static void A(int a){
		System.out.println(a);
	}

}
