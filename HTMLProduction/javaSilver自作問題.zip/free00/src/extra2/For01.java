package extra2;

public class For01 {

	
	
	public static void main(String[] args) {
		
		int[][] array = {{1,2,3},{4,5,6}};
		for(int i = 0,  j = 0; i < array.length; i++){
			
			System.out.print(array[i][j] + "★");
			j++;
			
		}

	}

}
