package extra2;

public class String01 {

	public static void main(String[] args) {
		String s = "01234";
		s.concat("A");
		String s2 = s.replace("0", "B");

		System.out.println(s2);

	}

}
