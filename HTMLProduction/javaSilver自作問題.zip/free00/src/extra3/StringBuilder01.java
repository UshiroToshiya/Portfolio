package extra3;

public class StringBuilder01 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("a bcd e");


		System.out.println(sb.capacity());

	}

}
