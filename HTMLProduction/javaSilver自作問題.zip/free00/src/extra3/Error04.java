package extra3;

public class Error04 {

	public static void main(String[] args) {
		int moji = Integer.parseInt("文字");
		System.out.println(moji);

	}

}
