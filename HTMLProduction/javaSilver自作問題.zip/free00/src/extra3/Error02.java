package extra3;

public class Error02 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();

		for(int i = 0; i < 3;){
			sb.append("Yeah!");
		}
	}

}
