package extra;

public class Math01 {

	public static void main(String[] args) {
		int a = (int)(Math.round(Math.pow(3.1, 2)));
		System.out.println(a);

	}

}
