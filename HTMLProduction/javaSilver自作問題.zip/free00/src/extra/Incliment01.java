package extra;

public class Incliment01 {

	public static void main(String[] args) {
		int a = 5;
		int b = --a - a++ + ++a - -a--;
		System.out.println(b);

	}

}
