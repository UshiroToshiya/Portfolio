package extra;

public class Math02 {

	public static void main(String[] args) {
		int a = 10 % 3 * 10 / 2 + 3;
		int b = (int)Math.random();
		int c = a * b;
		System.out.println(c);

	}

}
